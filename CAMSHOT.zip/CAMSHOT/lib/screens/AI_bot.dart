import 'package:CAMSHOT/utils/colors.dart';
import 'package:flutter/material.dart';
import 'dart:math';

class ChatScreen extends StatefulWidget {
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final ScrollController _scrollController = ScrollController();
  final List<String> _photographyThemes = [
    "Try capturing the beauty of nature today!",
    "How about street photography?",
    "Explore the world of macro photography!",
    "Try capturing the beauty of nature today! 🌳📷",
    "How about street photography? 🏙️📷",
    "Explore the world of macro photography! 🐞📷",
    "Capture the vibrant colors of a sunset or sunrise! 🌅📷",
    "Experiment with portrait photography! 👩‍🦰📷",
    "Focus on architectural details today! 🏛️📷",
    "Try your hand at black and white photography! ⚫⚪📷",
    "Capture the hustle and bustle of everyday life! 🚶‍♂️📷",
    "Discover the beauty in minimalism! 💫📷",
    "Go on a photo walk and see what catches your eye! 🚶‍♀️📷",
    "Explore abstract photography today! 🌀📷",
    "Find inspiration in patterns and textures! 🎨📷",
    "Document a day in your life through photography! 📸",
    "Capture the magic of candid moments! ✨📷",
    "Try aerial photography if you have access to a drone! 🚁📷",
    "Experiment with long exposure photography! 🌌📷",
    "Focus on capturing emotions in your photos! 😊📷",
    "Explore the beauty of symmetry! 🔄📷",
    "Try underwater photography if you have the equipment! 🌊📷",
    "Discover the art of food photography! 🍽️📷",
    "Find beauty in the mundane! 🌿📷",
    "Capture the essence of a cityscape! 🌆📷",
    "Experiment with light painting! 💡📷",
    "Try capturing reflections in your photos! 💧📷",
    "Focus on telling a story through your images! 📖📷",
    "Explore the world of experimental photography! 🎨📷",
    "Document the beauty of different cultures! 🌍📷",
    "Capture the energy of a live event! 🎉📷",
    "Try your hand at wildlife photography! 🐾📷",
    "Experiment with different perspectives and angles! 🔄📷",
    "Discover the beauty of still life photography! 🍇📷",
    "Capture the beauty of nature in your backyard.",
    "Document the changing seasons in your area.",
    "Experiment with macro photography and capture tiny details.",
    "Photograph interesting textures and patterns.",
    "Capture candid moments of everyday life.",
    "Explore urban landscapes and architecture.",
    "Document local culture and traditions.",
    "Experiment with black and white photography.",
    "Try your hand at portrait photography.",
    "Photograph the beauty of sunrise or sunset.",
    "Capture the motion and energy of a busy street.",
    "Document street art and graffiti in your city.",
    "Experiment with long exposure photography at night.",
    "Photograph the beauty of reflections in water.",
    "Explore the beauty of symmetry in architecture.",
    "Document the process of creating art or craft.",
    "Capture the emotion and expression of people's faces.",
    "Experiment with abstract photography.",
    "Photograph the beauty of natural landscapes.",
    "Capture the charm of old buildings and ruins.",
    "Explore the world of fashion photography.",
    "Document the vibrant colors of a local market.",
    "Experiment with silhouette photography.",
    "Photograph the beauty of flowers and plants.",
    "Capture the energy of a live concert or event.",
    "Explore the beauty of underwater life.",
    "Document the daily life of a street performer.",
    "Experiment with aerial photography using a drone.",
    "Photograph the details of insects and small creatures.",
    "Capture the beauty of clouds and sky formations.",
    "Explore the beauty of minimalism in photography.",
    "Document the process of preparing and cooking food.",
    "Experiment with light painting and light trails.",
    "Photograph the beauty of wildlife in its natural habitat.",
    "Capture the energy and excitement of sports events.",
    "Document the beauty of your travels and adventures.",
    "Experiment with perspective and angles.",
    "Photograph the beauty of historic landmarks.",
    "Capture the magic of starry nights and astrophotography.",
    "Explore the world of abstract art and photography.",
    "Document the beauty of different cultures and traditions.",
    "Experiment with panoramic photography.",
    "Photograph the beauty of rainbows after a storm.",
    "Capture the essence of a cityscape at golden hour.",
    "Explore the beauty of reflections in glass and mirrors.",
    "Document the beauty of wildlife in motion.",
  ];

  final List<ChatMessage> _messages = [];

  final TextEditingController _textController = TextEditingController();

  void _sendMessage(String message) {
    setState(() {
      _messages.add(ChatMessage(
        text: message,
        isUser: true,
      ));
      _messages.add(ChatMessage(
        text: _getBotResponse(message),
        isUser: false,
      ));
    });
    _textController.clear();
  }

  String _getBotResponse(String message) {
    setState(() {
      _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
    });
    if (message.toLowerCase() == 'hello' || message.toLowerCase() == 'hi') {
      return 'Hi there! Do you need photography idea?';
    } else if (message.toLowerCase() == 'how are you?') {
      return "I'm just a computer program, but I'm functioning as intended. How can I assist you with photography today?";
    } else if (message.toLowerCase() == 'who are you?') {
      return "I'm T-rex, an AI designed to assist with photography idea and inspiration, answer questions, and engage in conversation. Want to be my friend😉! ";
    } else if (message.toLowerCase() == 'I am sad') {
      return "${_photographyThemes[Random().nextInt(_photographyThemes.length)]}";
    } else if (message.toLowerCase() == 'yes') {
      return "Great! ${_photographyThemes[Random().nextInt(_photographyThemes.length)]}";
    } else if (message.toLowerCase() == 'no') {
      return "That's okay! How about trying something else?";
    } else if (message.toLowerCase() == 'ok') {
      return "Great choice! Let me know if you need more inspiration.";
    } else if (message.toLowerCase() == 'i need help') {
      return "Of course! I'm here to help. What do you need help with?";
    } else if (message.toLowerCase() == 'thank you') {
      return "You're welcome! I'm glad I could help.";
    } else if (message.toLowerCase() == 'i am done') {
      return "Okay, feel free to come back anytime you need more inspiration!";
    } else {
      return "Sorry, I didn't understand that. How about photography today?";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xffffffff),
        title: Row(
          children: [
            CircleAvatar(
              backgroundImage: const AssetImage('images/aa.jpg'),
              radius: 16,
            ),
            SizedBox(width: 8),
            Text(
              'T-rex',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              reverse: false,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return ChatBubble(
                  message: _messages[index],
                );
              },
            ),
          ),
          //Divider(),
          Row(
            children: <Widget>[
              Expanded(
                child: TextField(
                  controller: _textController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Type a message...',
                  ),
                ),
              ),
              SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.send),
                onPressed: () {
                  _sendMessage(_textController.text);
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;

  ChatMessage({required this.text, required this.isUser});
}

class ChatBubble extends StatelessWidget {
  final ChatMessage message;

  ChatBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        decoration: BoxDecoration(
          color: message.isUser ? Color(0xff5e0600) : Colors.black,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(message.isUser ? 0 : 16),
            topRight: Radius.circular(message.isUser ? 16 : 0),
            bottomLeft: Radius.circular(16),
            bottomRight: Radius.circular(16),
          ),
        ),
        child: Text(
          message.text,
          style: TextStyle(fontSize: 16, color: Colors.white),
        ),
      ),
    );
  }
}
