import 'package:CAMSHOT/screens/AI_bot.dart';
import 'package:CAMSHOT/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';

class CalendarScreen extends StatefulWidget {
  @override
  _CalendarScreenState createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Calendar'),
          backgroundColor: mobileBackgroundColor,
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6.0),
          child: SfCalendar(
            view:
                CalendarView.month, // Set initial view (e.g., month, week, day)
            // Set the data source for the events
          ),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            // Add your action here
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => ChatScreen(),
              ),
            );
          },
          tooltip: 'Ideas',
          child: const Icon(Icons.lightbulb_outline),
        ));
  }
}
