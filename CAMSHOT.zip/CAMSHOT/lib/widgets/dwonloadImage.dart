import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class ImageDownload extends StatefulWidget {
  final String imageUrl;

  ImageDownload({required this.imageUrl});

  @override
  _ImageDownloadState createState() => _ImageDownloadState();
}

class _ImageDownloadState extends State<ImageDownload> {
  String? _localPath;
  double _progress = 0;

  Future<void> _downloadImage() async {
    final status = await Permission.storage.request();
    if (status.isGranted) {
      final externalDir = await getExternalStorageDirectory();
      final response = await http.get(Uri.parse(widget.imageUrl));
      final file =
          File('${externalDir!.path}/${widget.imageUrl.split('/').last}');
      await file.writeAsBytes(response.bodyBytes);
      setState(() {
        _progress = 1;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Download completed')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Permission denied')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ElevatedButton(
          onPressed: _downloadImage,
          child: Text('Download'),
        ),
        if (_progress > 0)
          LinearProgressIndicator(
            value: _progress,
          ),
      ],
    );
  }
}
