import 'package:flutter/material.dart';

const mobileBackgroundColor = Color(0xfff1f1f1);
const webBackgroundColor = Color(0xfffbfbfb);
const mobileSearchColor = Color(0xfffe0000);
const blueColor = Color.fromRGBO(0, 149, 246, 1);
const primaryColor = Color(0xff000000);
const secondaryColor = Colors.black;
