import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:CAMSHOT/screens/add_post_screen.dart';
import 'package:CAMSHOT/screens/feed_screen.dart';
import 'package:CAMSHOT/screens/profile_screen.dart';
import 'package:CAMSHOT/screens/search_screen.dart';
import 'package:CAMSHOT/screens/cal_ender.dart';

const webScreenSize = 600;

List<Widget> homeScreenItems = [
  const FeedScreen(),
  const SearchScreen(),
  const AddPostScreen(),
  CalendarScreen(),
  ProfileScreen(
    uid: FirebaseAuth.instance.currentUser!.uid,
  ),
];
