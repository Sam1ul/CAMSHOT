import 'dart:async';
import 'package:CAMSHOT/responsive/mobile_screen_layout.dart';
import 'package:CAMSHOT/responsive/responsive_layout.dart';
import 'package:CAMSHOT/responsive/web_screen_layout.dart';
import 'package:flutter/material.dart';

class MysplashScreen2 extends StatefulWidget {
  const MysplashScreen2({Key? key}) : super(key: key);

  @override
  State<MysplashScreen2> createState() => _MysplashScreen2State();
}

class _MysplashScreen2State extends State<MysplashScreen2> {
  startTimer() {
    Timer(const Duration(seconds: 8), () async {
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(
            builder: (context) => const ResponsiveLayout(
              mobileScreenLayout: MobileScreenLayout(),
              webScreenLayout: WebScreenLayout(),
            ),
          ),
          (route) => false);
    });
  }

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        color: Color(0xffffffff),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(
                child: Container(),
                flex: 2,
              ),
              /*const Text(
                "Welcome",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: Color(0xffb98800),
                  fontSize: 40,
                  letterSpacing: 3,
                ),
              ),*/
              const SizedBox(
                height: 10,
              ),
              //Image.asset("images/jj.gif"),
              const SizedBox(
                height: 10,
              ),
              Image.asset("images/s.gif"),

              /*const Padding(
                padding: EdgeInsets.all(18.0),
                child: Text(
                  "Take Shots & Share\nImpress Everyone",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    letterSpacing: 3,
                  ),
                ),
              ),*/
              Flexible(
                child: Container(),
                flex: 2,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
