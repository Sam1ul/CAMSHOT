import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Support'),
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'CAMSHOT',
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              'Description:',
              style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8.0),
            Text(
              'CAMSHOT is the ultimate platform for sharing and discovering captivating images from around the world. Whether you\'re an amateur photographer, a seasoned professional, or simply an enthusiast, CAMSHOT provides a seamless experience for showcasing your best work and exploring stunning visuals curated by the community. With easy-to-use features and a vibrant community, CAMSHOT is where creativity thrives.',
              style: TextStyle(fontSize: 16.0),
            ),
            SizedBox(height: 16.0),
            Text(
              'Contact Information:',
              style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 4.0),
            Text(
              'Address:',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'TEAM CAMSHOT.\nVarendra University\nDept. of CSE\nRajshahi,Bangladesh',
              style: TextStyle(fontSize: 16.0),
            ),
            SizedBox(height: 8.0),
            Text(
              'Email:',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '222311011@vu.edu.bd\n222311013@vu.edu.bd',
              style: TextStyle(fontSize: 16.0),
            ),
            SizedBox(height: 8.0),
            Text(
              'Reference:',
              style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Flutter & Firebase Course - Build a Full Stack Instagram Clone',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Course developed by Rivaan Ranawat.',
              style: TextStyle(
                fontSize: 16.0,
              ),
            ),
            SelectableText(
              'https://www.youtube.com/watch?v=mEPm9w5QlJM&t=138s',
              style: TextStyle(
                fontSize: 16.0,
              ),
            ),
            Text(
              'Flutter Course for Beginners - 37-hour Cross Platform App Development Tutorial',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Course developed by Vandad Nahavandipoor.',
              style: TextStyle(
                fontSize: 16.0,
              ),
            ),
            SelectableText(
              'https://www.youtube.com/watch?v=VPvVD8t02U8',
              style: TextStyle(
                fontSize: 16.0,
              ),
            ),
            SizedBox(height: 4.0),
            Text(
              'https://www.instagram.com/',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
 	    SizedBox(height: 4.0),
            Text(
              'And images from various internet source',
              style: TextStyle(
                fontSize: 16.0,
              ),
            ),

            //
          ],
        ),
      ),
    );
  }
}
